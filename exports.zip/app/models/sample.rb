class Sample < ApplicationRecord
end
